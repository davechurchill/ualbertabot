SparCraft - 2013
David Churchill - dave.churchill@gmail.com


For documentation please visit:

https://code.google.com/p/sparcraft/


To Run:

In terminal run SparCraft.exe sample_exp.txt

OR

In windows drag sample_exp.txt onto SparCraft.exe